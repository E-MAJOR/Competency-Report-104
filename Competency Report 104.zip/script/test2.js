// console.log('test2');
// let dog={
//     name:'Rocky',
//     age:1,
//     run:function(){
//         console.log(this.nameIs+' is running');
//     }

// }
// console.log(dog);
// let cat={
//     name:'Garfield',
//     age:10,
//     run:function(){
//         console.log(this.nameIs+' is running');
//     }
    
// }
// console.log(cat);
// //object constructor
// function Animal(n, a, o){
//     this.name=n;
//     this.age=a;
//     this.owner=o;

// }
// let dog1=new Animal("Scooby",58, "Shaggy");
// console.log(dog1);

// let dog2=new Animal("Buffalo", 13, "William");
// console.log(dog2);

// let cat1=new Animal('Drake', 7, 'Mark');
// console.log(cat1);


